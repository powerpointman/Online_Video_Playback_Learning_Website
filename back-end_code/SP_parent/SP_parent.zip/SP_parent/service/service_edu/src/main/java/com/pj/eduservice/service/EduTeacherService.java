package com.pj.eduservice.service;

import com.pj.eduservice.entity.EduTeacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 讲师 服务类
 * </p>
 *
 * @author testjava
 * @since 2023-03-21
 */
public interface EduTeacherService extends IService<EduTeacher> {

}
