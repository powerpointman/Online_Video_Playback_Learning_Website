package com.pj.eduservice.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan("com.pj.eduservice.mapper")
public class EduConfig {

}
